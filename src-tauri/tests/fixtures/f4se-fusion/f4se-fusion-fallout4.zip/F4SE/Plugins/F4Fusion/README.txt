fixture: F4SE/Plugins/F4Fusion/README.txt
